/******************************************************************************

 Global declarations and definitions.

******************************************************************************/

#ifndef GLOBAL_H
#define GLOBAL_H

#include <string>

#include "config.h"

using namespace std;

#endif
